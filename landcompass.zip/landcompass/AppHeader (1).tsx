import { Link } from "@tanstack/react-router";
import { useI18n } from "@/lib/i18n";
import { supabase } from "@/integrations/supabase/client";
import { useEffect, useState } from "react";

const LANGS: { code: "en" | "hi" | "ta" | "te"; label: string }[] = [
  { code: "en", label: "EN" },
  { code: "hi", label: "हिं" },
  { code: "ta", label: "த" },
  { code: "te", label: "తె" },
];

export function LanguageToggle() {
  const { lang, setLang } = useI18n();
  return (
    <div className="inline-flex rounded-full border bg-card p-0.5 text-xs font-medium">
      {LANGS.map((l) => (
        <button
          key={l.code}
          onClick={() => setLang(l.code)}
          className={`px-2.5 py-1 rounded-full transition ${
            lang === l.code ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
          }`}
        >
          {l.label}
        </button>
      ))}
    </div>
  );
}


export function AppHeader({ authed }: { authed: boolean }) {
  const { t } = useI18n();
  const [email, setEmail] = useState<string | null>(null);
  useEffect(() => {
    if (!authed) return;
    supabase.auth.getUser().then(({ data }) => setEmail(data.user?.email ?? null));
  }, [authed]);

  return (
    <header className="sticky top-0 z-40 border-b border-white/10 bg-black/95 backdrop-blur">
      <div className="mx-auto flex h-14 max-w-6xl items-center justify-between px-4">
        <Link to="/" className="flex items-center gap-2 font-display text-lg font-bold tracking-wide">
          <span className="grid h-7 w-7 place-items-center rounded-md text-sm" style={{ background: "linear-gradient(180deg,#FFC857,#F5A623)", color: "#0A1628" }}>भू</span>
          <span style={{ color: "#F5A623" }}>{t.appName}</span>
        </Link>

        <nav className="flex items-center gap-3">
          {authed && (
            <>
              <Link to="/app" className="text-sm text-muted-foreground hover:text-foreground">
                {t.newAnalysis}
              </Link>
              <Link to="/pg" className="text-sm text-muted-foreground hover:text-foreground">
                {t.pgCta}
              </Link>
              <Link to="/history" className="text-sm text-muted-foreground hover:text-foreground">
                {t.history}
              </Link>
            </>
          )}

          <LanguageToggle />
          {authed ? (
            <button
              onClick={async () => {
                await supabase.auth.signOut();
                window.location.href = "/";
              }}
              className="text-sm text-muted-foreground hover:text-foreground"
              title={email ?? ""}
            >
              {t.signOut}
            </button>
          ) : (
            <Link
              to="/auth"
              className="rounded-md bg-primary px-3 py-1.5 text-sm font-medium text-primary-foreground hover:bg-primary/90"
            >
              {t.signIn}
            </Link>
          )}
        </nav>
      </div>
    </header>
  );
}
